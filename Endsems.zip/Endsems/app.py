import os
from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return f"Application Version {os.getenv('APP_VERSION', '1.0')}"

app.run(host="0.0.0.0", port=5000)