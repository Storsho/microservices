import os
from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return f"Application Version {os.getenv('APP_VERSION', '1.0')}"

app.run(host="0.0.0.0", port=5000)

######################

from flask import Flask
import psycopg2

app = Flask(__name__)

@app.route("/")
def home():
    try:
        conn = psycopg2.connect(
            host="db",
            database="college",
            user="student",
            password="student123"
        )
        conn.close()
        return "Web application connected to database"
    except Exception as e:
        return str(e), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)