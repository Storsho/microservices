from flask import Flask, render_template, jsonify

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/student")
def student():
    return jsonify({
        "name":"sudharshan",
        "department":"CSE",
        "register_no":"3122237001054"
    })
    
if __name__ == "__main__":
    app.run(host="0.0.0.0",port=5000)