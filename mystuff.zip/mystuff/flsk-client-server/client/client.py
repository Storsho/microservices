import time 
import requests

server_url = "http://server:5000"

for attempt in range(10):
    try:
        response = requests.get(server_url + "/",timeout=3)
        print(response.text)
        
    except requests.RequestException as error:
        print("error")
        time.sleep(2)